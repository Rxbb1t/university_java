package VehicleManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
class LoadDatabase {

	private static final Logger log = LoggerFactory.getLogger(LoadDatabase.class);

	@Bean
	CommandLineRunner initDatabase(VehicleRepository repository) {

		return args -> {
			log.info("Preloading " + repository.save(new Vehicle("BMW","M3",503,true,false, Vehicle.EmissionEuro.EURO6)));
			log.info("Preloading " + repository.save(new Vehicle("Tesla","S",670,false,true,Vehicle.EmissionEuro.EURO6)));
			log.info("Preloading " + repository.save(new Vehicle("Nissan","Leaf",214,false,true,Vehicle.EmissionEuro.EURO5)));
		};
	}
}

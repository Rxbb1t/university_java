package VehicleManager;

import java.util.Objects;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
class Vehicle {

	private @Id @GeneratedValue Long id;
	private String name;
	private String model;
	private int horsePower;
	private Boolean isManual;
	private Boolean isElectric;
	public enum EmissionEuro { EURO1,
								EURO2,
								EURO3,
								EURO4,
								EURO5,
								EURO6 }
	private EmissionEuro euroType;

	Vehicle() {}

	Vehicle(String name, String model, int horsePower, Boolean isManual, Boolean isElectric, EmissionEuro euroType) {
		this.name = name;
		this.model = model;
		this.horsePower = horsePower;
		this.isManual = isManual;
		this.isElectric = isElectric;
		this.euroType = euroType;
	}

	public Long getId() {
		return this.id;
	}

	public String getName() {
		return this.name;
	}

	public String getModel() {
		return this.model;
	}

	public int getHorsePower(){
		return this.horsePower;
	}

	public Boolean getIsManual(){
		return this.isManual;
	}

	public Boolean getIsElectric(){
		return this.isElectric;
	}

	public EmissionEuro getEuroType(){
		return this.euroType;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public void setHorsePower(int horsePower){
		this.horsePower = horsePower;
	}

	public void setIsManual(Boolean isManual){
		this.isManual = isManual;
	}

	public void setIsElectric(Boolean isElectric){
		this.isElectric = isElectric;
	}

	public void setEuroType(EmissionEuro euroType){
		this.euroType = euroType;
	}

	@Override
	public boolean equals(Object o) {

		if (this == o)
			return true;
		if (!(o instanceof Vehicle))
			return false;
		Vehicle Vehicle = (Vehicle) o;
		return Objects.equals(this.id, Vehicle.id)
				&& Objects.equals(this.name, Vehicle.name)
				&& Objects.equals(this.model, Vehicle.model)
				&& Objects.equals(this.horsePower, Vehicle.horsePower)
				&& Objects.equals(this.isManual, Vehicle.isManual)
				&& Objects.equals(this.isElectric, Vehicle.isElectric)
				&& Objects.equals(this.euroType, Vehicle.euroType);
	}

	@Override
	public int hashCode() {
		return Objects.hash(this.id, this.name, this.model, this.horsePower, this.isManual, this.isElectric, this.euroType);
	}

	@Override
	public String toString() {
		return "Vehicle{"
				+ "id=" + this.id
				+ ", name='" + this.name + '\''
				+ ", model='" + this.model + '\''
				+ ", horse power='" + this.horsePower + '\''
				+ ", is manual='" + this.isManual + '\''
				+ ", is electric='" + this.isElectric + '\''
				+ ", euro type='" + this.euroType + '\''
				+ '}';
	}
}

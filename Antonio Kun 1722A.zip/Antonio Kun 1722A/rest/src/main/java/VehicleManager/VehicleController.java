package VehicleManager;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

// tag::hateoas-imports[]
// end::hateoas-imports[]

@RestController
class VehicleController {

	private final VehicleRepository repository;

	VehicleController(VehicleRepository repository) {
		this.repository = repository;
	}

	// Aggregate root

	// tag::get-aggregate-root[]
	@GetMapping("/vehicles")
	CollectionModel<EntityModel<Vehicle>> all() {

		List<EntityModel<Vehicle>> Vehicles = repository.findAll().stream()
				.map(Vehicle -> EntityModel.of(Vehicle,
						linkTo(methodOn(VehicleController.class).one(Vehicle.getId())).withSelfRel(),
						linkTo(methodOn(VehicleController.class).all()).withRel("Vehicles")))
				.collect(Collectors.toList());

		return CollectionModel.of(Vehicles, linkTo(methodOn(VehicleController.class).all()).withSelfRel());
	}
	// end::get-aggregate-root[]

	@PostMapping("/vehicles")
	Vehicle newVehicle(@RequestBody Vehicle newVehicle) {
		return repository.save(newVehicle);
	}

	// Single item

	// tag::get-single-item[]
	@GetMapping("/vehicles/{id}")
	EntityModel<Vehicle> one(@PathVariable Long id) {

		Vehicle Vehicle = repository.findById(id) //
				.orElseThrow(() -> new VehicleNotFoundException(id));

		return EntityModel.of(Vehicle, //
				linkTo(methodOn(VehicleController.class).one(id)).withSelfRel(),
				linkTo(methodOn(VehicleController.class).all()).withRel("Vehicles"));
	}
	// end::get-single-item[]

	@PutMapping("/vehicles/{id}")
	Vehicle replaceVehicle(@RequestBody Vehicle newVehicle, @PathVariable Long id) {

		return repository.findById(id) //
				.map(Vehicle -> {
					Vehicle.setName(newVehicle.getName());
					Vehicle.setModel(newVehicle.getModel());
					Vehicle.setHorsePower(newVehicle.getHorsePower());
					Vehicle.setIsManual(newVehicle.getIsManual());
					Vehicle.setIsElectric((newVehicle.getIsElectric()));
					Vehicle.setEuroType(newVehicle.getEuroType());
					return repository.save(Vehicle);
				}) //
				.orElseGet(() -> {
					newVehicle.setId(id);
					return repository.save(newVehicle);
				});
	}

	@DeleteMapping("/vehicles/{id}")
	void deleteVehicle(@PathVariable Long id) {
		repository.deleteById(id);
	}
}

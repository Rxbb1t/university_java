import java.util.ArrayList;
import java.util.Scanner;

class Employee {
    private String name,email;
    private double hourRate;
    private int capacity,freeDays;
    public Employee(String name, String email, double hourRate, int capacity, int freeDays) {
        this.name = name;
        this.email = email;
        this.hourRate = hourRate;
        this.capacity = capacity;
        this.freeDays = freeDays;
    }
    public double calculateMonthlyIncome() {
        return hourRate * capacity * (21 - freeDays);
    }
    public String getName() {
        return name;
    }
}
public class Lab5 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Introdu nr de angajati (N): ");
        int n = scanner.nextInt();

        ArrayList<Employee> employees = new ArrayList<>();

        for (int i = 0; i < n; i++) {
            System.out.println("Detalii angajat #" + (i + 1));

            System.out.print("Introdu numele: ");
            String name = scanner.next();

            System.out.print("Introdu emailul: ");
            String email = scanner.next();

            System.out.print("Introdu rata pe oră: ");
            double hourRate = scanner.nextDouble();

            System.out.print("Introdu orele pe zi: ");
            int capacity = scanner.nextInt();

            System.out.print("Introdu zilele libere: ");
            int freeDays = scanner.nextInt();

            employees.add(new Employee(name, email, hourRate, capacity, freeDays));
        }

        System.out.println("\nSalarii lunare:");
        for (Employee employee : employees) {
            System.out.println(employee.getName() + ": $" + employee.calculateMonthlyIncome());
        }
        scanner.close();
    }
}

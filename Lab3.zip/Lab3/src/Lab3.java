public class Lab3 {
    public static void main(String[] args) {

        String[] a = {"java", "test", "university"};
        String[] b = {"car", "university", "plane"};
        afiseazaElementeComune(a, b);

        afiseazaPrime();


        int n = 20;
        afiseazaFibonacci(n);


        String cuvant = "palindrom";
        verificaPalindrom(cuvant);
    }

    // Problema 1
    public static void afiseazaElementeComune(String[] a, String[] b) {
        System.out.println("Elementele comune sunt:");
        for (String element : a) {
            if (containsElement(b, element)) {
                System.out.println(element);
            }
        }
    }

    public static boolean containsElement(String[] array, String element) {
        for (String currentElement : array) {
            if (currentElement.equals(element)) {
                return true;
            }
        }
        return false;
    }

    // Problema 2
    public static void afiseazaPrime() {
        System.out.println("\nNumerele prime sunt:");
        for (int i = 2; i <= 20; i++) {
            if (isPrim(i)) {
                System.out.print(i + " ");
            }
        }
        System.out.println();
    }

    public static boolean isPrim(int numar) {
        if (numar < 2) {
            return false;
        }
        for (int i = 2; i <= numar / 2; i++) {
            if (numar % i == 0) {
                return false;
            }
        }
        return true;
    }

    // Problema 3
    public static void afiseazaFibonacci(int n) {
        System.out.println("\nSirul Fibonacci pana la " + n + " este:");
        int a = 0, b = 1;
        while (a <= n) {
            System.out.print(a + " ");
            int sum = a + b;
            a = b;
            b = sum;
        }
        System.out.println();
    }

    // Problema 4
    public static void verificaPalindrom(String cuvant) {
        System.out.println("\nCuvantul \"" + cuvant + "\" este palindrom: " + isPalindrom(cuvant));
    }

    public static boolean isPalindrom(String cuvant) {
        int lungime = cuvant.length();
        for (int i = 0; i < lungime / 2; i++) {
            if (cuvant.charAt(i) != cuvant.charAt(lungime - i - 1)) {
                return false;
            }
        }
        return true;
    }
}

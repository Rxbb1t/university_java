import java.util.Arrays;

public class Lab4 {

    public static void main(String[] args) {
        //
        String cuvant1 = "masina";
        System.out.println("Mijlocul cuvantului '" + cuvant1 + "' este: " + mijlocCuvant(cuvant1));


        int numar = 254;
        System.out.println("Suma cifrelor lui " + numar + " este: " + sumaCifrelor(numar));

        Caine caine1 = new Caine("Benji", "Labrador");
        Caine caine2 = new Caine("Rex", "Golden Retriever");

        caine1.setRasa("Bichon Havanez");
        caine2.setNume("Cassie");

        System.out.println("\nDetalii caini:");
        System.out.println(caine1.getNume() + " - " + caine1.getRasa());
        System.out.println(caine2.getNume() + " - " + caine2.getRasa());

        Dreptunghi dreptunghi = new Dreptunghi();
        dreptunghi.setLatime(5.0);
        dreptunghi.setLungime(10.0);

        System.out.println("\nAria dreptunghiului: " + dreptunghi.calculeazaArie());
        System.out.println("Perimetrul dreptunghiului: " + dreptunghi.calculeazaPerimetru());

        Persoana persoana = new Persoana("Ionut", "ionut@ionut.com");
        Student student = new Student("Vlad", "vladtepes@gmail.com", new int[]{9, 8, 10});
        Profesor profesor = new Profesor("Coman", "comansimina@gmail.com", new String[]{"Matematica", "Informatica"});

        System.out.println("\nDetalii Persoana: " + persoana.getNume() + ", " + persoana.getEmail());

        System.out.println("Detalii Student: " + student.getNume() + ", " + student.getEmail() + ", Note: " + arrayToString(student.getNote()));
        System.out.println("Detalii Profesor: " + profesor.getNume() + ", " + profesor.getEmail() + ", Cursuri: " + arrayToString(profesor.getCursuri()));
    }

    // Problema 1
    public static String mijlocCuvant(String cuvant) {
        int lungime = cuvant.length();
        if (lungime % 2 == 0) {
            return cuvant.substring(lungime / 2 - 1, lungime / 2 + 1);
        } else {
            return cuvant.substring(lungime / 2, lungime / 2 + 1);
        }
    }

    // Problema 2
    public static int sumaCifrelor(int numar) {
        int suma = 0;
        while (numar != 0) {
            suma += numar % 10;
            numar /= 10;
        }
        return suma;
    }
    static class Caine {
        private String nume,rasa;
        public Caine(String nume, String rasa) {
            this.nume = nume;
            this.rasa = rasa;
        }

        public String getNume() {
            return nume;
        }

        public void setNume(String nume) {
            this.nume = nume;
        }

        public String getRasa() {
            return rasa;
        }

        public void setRasa(String rasa) {
            this.rasa = rasa;
        }
    }
    static class Dreptunghi {
        private double latime,lungime;

        public double getLatime() {
            return latime;
        }

        public void setLatime(double latime) {
            this.latime = latime;
        }

        public double getLungime() {
            return lungime;
        }

        public void setLungime(double lungime) {
            this.lungime = lungime;
        }

        public double calculeazaArie() {
            return latime * lungime;
        }

        public double calculeazaPerimetru() {
            return 2 * (latime + lungime);
        }
    }

    static class Persoana {
        private String nume;
        private String email;

        public Persoana(String nume, String email) {
            this.nume = nume;
            this.email = email;
        }

        public String getNume() {
            return nume;
        }

        public void setNume(String nume) {
            this.nume = nume;
        }

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }
    }

    static class Student extends Persoana {
        private int[] note;

        public Student(String nume, String email, int[] note) {
            super(nume, email);
            this.note = note;
        }

        public int[] getNote() {
            return note;
        }
    }
    static class Profesor extends Persoana {
        private String[] cursuri;
        public Profesor(String nume, String email, String[] cursuri) {
            super(nume, email);
            this.cursuri = cursuri;
        }

        public String[] getCursuri() {
            return cursuri;
        }
    }

    public static String arrayToString(Object[] array) {
        return Arrays.toString(array);
    }
    public static String arrayToString(int[] array) {
        return Arrays.toString(array);
    }

    public static String arrayToString(String[] array) {
        return Arrays.toString(array);
    }
}

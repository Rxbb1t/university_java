// problema 2 lab5

class Vehicul {
    private String marca;
    private int anFabricatie;
    public Vehicul(String marca, int anFabricatie) {
        setDetaliiVehicul(marca, anFabricatie);
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public int getAnFabricatie() {
        return anFabricatie;
    }

    public void setAnFabricatie(int anFabricatie) {
        this.anFabricatie = anFabricatie;
    }

    private void setDetaliiVehicul(String marca, int anFabricatie) {
        setMarca(marca);
        setAnFabricatie(anFabricatie);
    }
}

class Masina extends Vehicul {
    private double capacitateMotor;

    public Masina(String marca, int anFabricatie, double capacitateMotor) {
        super(marca, anFabricatie);
        setCapacitateMotor(capacitateMotor);
    }

    public double getCapacitateMotor() {
        return capacitateMotor;
    }

    public void setCapacitateMotor(double capacitateMotor) {
        this.capacitateMotor = capacitateMotor;
    }
}

class Bicicleta extends Vehicul {
    private int nrViteze;

    public Bicicleta(String marca, int anFabricatie, int nrViteze) {
        super(marca, anFabricatie);
        setNrViteze(nrViteze);
    }

    public int getNrViteze() {
        return nrViteze;
    }

    public void setNrViteze(int nrViteze) {
        this.nrViteze = nrViteze;
    }
}

public class Lab5 {
    public static void main(String[] args) {
        Masina masina = new Masina("Mercedes-Benz", 2006, 1.9);
        Bicicleta bicicleta = new Bicicleta("Carpat", 2018, 8);

        System.out.printf("Masina: %s, %d, %.2f%n", masina.getMarca(), masina.getAnFabricatie(), masina.getCapacitateMotor());
        System.out.printf("Bicicleta: %s, %d, %d%n", bicicleta.getMarca(), bicicleta.getAnFabricatie(), bicicleta.getNrViteze());
    }
}
